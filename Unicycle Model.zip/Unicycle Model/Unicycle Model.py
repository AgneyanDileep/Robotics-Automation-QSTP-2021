"""Week I Assignment
Simulate the trajectory of a robot approximated using a unicycle model given the
following start states, dt, velocity commands and timesteps
State = (x, y, theta);
Velocity = (v, w) 
1. Start=(0, 0, 0); dt=0.1; vel=(1, 0.5); timesteps: 25
2. Start=(0, 0, 1.57); dt=0.2; vel=(0.5, 1); timesteps: 10
3. Start(0, 0, 0.77); dt=0.05; vel=(5, 4); timestep: 50
Upload the completed python file and the figures of the three sub parts in classroom
"""
import math
import numpy as np
import matplotlib.pyplot as plt

x_coord = [0]
y_coord = [0]

class Unicycle:
    def __init__(self, x: float, y: float, theta: float, dt: float):
        self.x = x
        self.y = y
        self.theta = theta
        self.dt = dt

    def step(self, v: float, w: float, n: int):
        for i in np.arange(0,n*self.dt,self.dt):
            self.x = self.x + v*math.cos(self.theta)*self.dt 
            x_coord.append(self.x)
            self.y = self.y + v*math.sin(self.theta)*self.dt
            y_coord.append(self.y)
            self.theta = self.theta + w*self.dt
            # Store the points of the trajectory to plot
            self.x_points = [self.x]
            self.y_points = [self.y]
        return self.x, self.y, self.theta

    def plot(self, v: float, w: float):
        """Function that plots the intermeditate trajectory of the Robot"""
        plt.title(f"Unicycle Model: {v}, {w}")
        plt.xlabel("X-Coordinates")
        plt.ylabel("Y-Coordinates")
        plt.plot(x_coord, y_coord, color="red", alpha=0.75)
        plt.grid()
        plt.show()

if __name__ == "__main__":
    print("Unicycle Model Assignment")
    Robot = Unicycle(0,0,0,0.1)
    Robot.step(1,0.5,25)
    Robot.plot(1,0.5)
    Robot = Unicycle(0,0,1.57,0.2)
    Robot.step(0.5,1,10)
    Robot.plot(0.5,1)
    Robot = Unicycle(0,0,0.77,0.05)
    Robot.step(5,4,50)
    Robot.plot(5,4)

    # make an object of the robot and plot various trajectories'